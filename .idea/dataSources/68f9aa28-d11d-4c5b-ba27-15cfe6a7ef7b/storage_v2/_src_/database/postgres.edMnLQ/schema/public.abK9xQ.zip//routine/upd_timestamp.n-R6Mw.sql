create function upd_timestamp()
  returns trigger
language plpgsql
as $$
BEGIN
    NEW.update_time = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

