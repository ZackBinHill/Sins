create function data_trigger_func()
  returns trigger
language plpgsql
as $$
BEGIN
            if (TG_OP = 'INSERT') then
                NEW.created_by = user;
                NEW.created_date = CURRENT_TIMESTAMP;
                NEW.update_by = user;
                NEW.update_time = CURRENT_TIMESTAMP;
                insert into log_table(
                    table_name,
                    event_data_id,
                    event,
                    event_date,
                    event_by_user)
                values (
                    TG_TABLE_NAME,
                    NEW.id,
                    TG_OP,
                    CURRENT_TIMESTAMP,
                    user);
                RETURN NEW;
            elsif (TG_OP = 'UPDATE') then
                NEW.update_by = user;
                NEW.update_time = CURRENT_TIMESTAMP;
                insert into log_table(
                    table_name,
                    event_data_id,
                    event,
                    event_date,
                    event_by_user)
                values (
                    TG_TABLE_NAME,
                    NEW.id,
                    TG_OP,
                    CURRENT_TIMESTAMP,
                    user);
                RETURN NEW;
            elsif (TG_OP = 'DELETE') then
                insert into log_table(
                    table_name,
                    event_data_id,
                    event,
                    event_date,
                    event_by_user)
                values (
                    TG_TABLE_NAME,
                    OLD.id,
                    TG_OP,
                    CURRENT_TIMESTAMP,
                    user);
                RETURN OLD;
            end if;
            RETURN null;
        END;
$$;

